/*=================================
    init aos CSS start
===================================*/
AOS.init({
    once: true,
    offset: 20,
});
window.addEventListener("load", AOS.refresh);